export const API_URL = 'http://localhost:3001';
export const GOOGLE_CLIENT_ID = '776676760586-oeh418goat5ve4ng1r7dt0c2l9s5ihhv.apps.googleusercontent.com';