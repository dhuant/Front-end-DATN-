export const GRID = 'GRID'
export const LIST = 'LIST'